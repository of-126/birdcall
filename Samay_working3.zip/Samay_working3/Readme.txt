Author 			: 	Adheep Arya G R
Organization 	: 	CDAC Bangalore
Date			:	24/12/2024
Board			:	SAMAY

Project Name	:	Samay_v1
					Project to save a Text file in SD Card
					select SD Card and save data 
					Problem : All not working at same time.	
					
Link	:	https://controllerstech.com/interface-sd-card-with-sdio-in-stm32/
			https://stackoverflow.com/questions/76647117/sd-card-issue-in-sdio-peripheral-in-stm32f407vet6-black-board
